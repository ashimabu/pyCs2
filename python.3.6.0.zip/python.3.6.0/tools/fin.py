import numpy as np
from matplotlib import pyplot as plt

def saveFigTest():
    x = [1,2,3,4]
    y = np.sin(x)
    plt.plot(x,y)
    plt.savefig(r'C:\Users\user\Desktop\c\pyCs2\test.png')
